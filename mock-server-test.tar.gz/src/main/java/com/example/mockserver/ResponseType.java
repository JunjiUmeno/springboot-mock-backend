package com.example.mockserver;


public class ResponseType {

  public String something;

}
